class BusinessProcessEngine:
    def __init__(self, IC):
        self.__IC = IC
