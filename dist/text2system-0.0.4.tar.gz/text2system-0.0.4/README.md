# text2system
Text2System Experiment

## Before deploy setup the follow environment variables:
DJANGO_SUPERUSER_USERNAME=some_user_name<br/>
DJANGO_SUPERUSER_PASSWORD=some_password<br/>
DJANGO_SUPERUSER_EMAIL=some_email<br/>

