class ExternalService:
    def __init__(self, IE):
        self.__IE = IE
