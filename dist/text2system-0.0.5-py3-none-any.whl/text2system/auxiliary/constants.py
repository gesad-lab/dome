#global constants
OPR_APP_HOME_WEB = 'app.home.web'
OPR_APP_HOME_CMD = 'app.home.cmd'
OPR_ENTITY_ADD = 'entity.add'
OPR_ATTRIBUTE_ADD = 'attribute.add'
OPR_BOT_HANDLE_GET = 'bot.handle.get'
