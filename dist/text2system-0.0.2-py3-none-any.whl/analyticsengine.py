class AnalyticsEngine:
    def __init__(self, IC):
        self.__IC = IC
